"use client"

import type React from "react"
import { useEffect, useState } from "react"
import {
  ArrowLeft,
  Check,
  Phone,
  MoreVertical,
  Paperclip,
  Mic,
  Send,
  Smartphone,
  QrCode,
  Copy,
  CreditCard
} from "lucide-react"

type View = "summary" | "payment" | "pix" | "card" | "processing" | "success" | "chat"

const GREEN = "#00C896"
const DARK = "#0F172A"
const MINT = "#CFEFEC"

export default function CheckoutFlow() {
  const [view, setView] = useState<View>("summary")

  return (
    <div className="w-full min-h-screen flex items-center justify-center bg-gray-900 p-4">
      <div className="w-full max-w-[375px] h-[812px] max-h-[812px] mx-auto bg-[#CFEFEC] shadow-2xl relative overflow-hidden rounded-[2.5rem] border-[6px] border-gray-900 flex flex-col">
        {view === "summary" && <SummaryView onContinue={() => setView("payment")} />}
        {view === "payment" && (
          <PaymentView 
            onBack={() => setView("summary")} 
            onPayPix={() => setView("pix")}
            onPayCard={() => setView("card")} 
          />
        )}
        {view === "pix" && (
          <PixView 
            onBack={() => setView("payment")} 
            onSimulate={() => setView("processing")} 
          />
        )}
        {view === "card" && (
          <CardPaymentView 
            onBack={() => setView("payment")} 
            onPay={() => setView("processing")} 
          />
        )}
        {view === "processing" && <ProcessingView onDone={() => setView("success")} />}
        {view === "success" && <SuccessView onChat={() => setView("chat")} />}
        {view === "chat" && <ChatView onBack={() => setView("summary")} />}
      </div>
    </div>
  )
}

/* ---------------- View 1: Summary ---------------- */
function SummaryView({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="flex flex-col h-full">
      <header
        className="px-5 pt-6 pb-5 flex items-center gap-3 rounded-b-3xl"
        style={{ backgroundColor: GREEN }}
      >
        <button className="p-2 -ml-2 rounded-full hover:bg-black/10 transition-colors">
          <ArrowLeft className="h-6 w-6" style={{ color: DARK }} />
        </button>
        <h1 className="text-lg font-bold" style={{ color: DARK }}>
          Resumo da compra
        </h1>
      </header>

      <div className="flex-1 overflow-y-auto">
        {/* Product */}
        <div className="px-5 pt-6 flex items-center gap-4">
          <div className="bg-white rounded-2xl p-2 shadow-sm shrink-0">
            <img
              src="/notebook-dell.png" 
              alt="Notebook Dell"
              className="h-20 w-24 object-contain"
            />
          </div>
          <div>
            <h2 className="text-lg font-bold" style={{ color: DARK }}>
              Notebook Dell
            </h2>
            <p className="text-sm text-slate-500">Vendido por Irinel Silva</p>
          </div>
        </div>

        {/* Cost breakdown */}
        <div className="mt-6 mx-3 rounded-2xl bg-white/40 px-5 py-4">
          <Row label="Subtotal" value="R$ 1.200,00" />
          <Row label="Retirada" value="Presencial (Grátis)" />
        </div>

        <div className="mx-3 mt-3 border-t border-slate-300/60" />

        <div className="px-5 py-4 flex items-center justify-between">
          <span className="text-lg font-bold" style={{ color: DARK }}>
            Total
          </span>
          <span className="text-lg font-bold" style={{ color: DARK }}>
            R$ 1.200,00
          </span>
        </div>

        <div className="px-5 mt-2 space-y-4 text-sm">
          <div>
            <p className="text-slate-500">Ponto de encontro:</p>
            <p style={{ color: DARK }}>A combinar no chat.</p>
          </div>
          <div>
            <p className="text-slate-500">Forma de pagamento</p>
            <p style={{ color: DARK }}>Continue para selecionar a forma de pagamento</p>
          </div>
        </div>
      </div>

      <div className="p-5">
        <PrimaryButton onClick={onContinue}>Continuar</PrimaryButton>
      </div>
    </div>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-1.5">
      <span className="text-slate-600">{label}</span>
      <span className="font-medium" style={{ color: DARK }}>
        {value}
      </span>
    </div>
  )
}

/* ---------------- View 2: Payment Options ---------------- */
function PaymentView({ onBack, onPayPix, onPayCard }: { onBack: () => void; onPayPix: () => void; onPayCard: () => void }) {
  const [selected, setSelected] = useState("pix") 

  const cardOptions = [
    { id: "avista", label: "À vista", value: "R$ 1.200,00" },
    { id: "2x", label: "2x de R$ 650,00", value: "R$ 1.300,00" },
    { id: "3x", label: "3x de R$ 700,00", value: "R$ 1.400,00" },
    { id: "6x", label: "6x de R$ 750,00", value: "R$ 1.500,00" },
  ]

  const handleNext = () => {
    if (selected === "pix") onPayPix()
    else onPayCard()
  }

  return (
    <div className="flex flex-col h-full">
      <header
        className="px-5 pt-6 pb-5 flex items-center gap-3 rounded-b-3xl"
        style={{ backgroundColor: GREEN }}
      >
        <button onClick={onBack} aria-label="Voltar" className="p-2 -ml-2 rounded-full hover:bg-black/10 transition-colors">
          <ArrowLeft className="h-6 w-6" style={{ color: DARK }} />
        </button>
        <h1 className="text-lg font-bold" style={{ color: DARK }}>
          Escolha o pagamento
        </h1>
      </header>

      <div className="flex-1 overflow-y-auto px-5 pt-6">
        {/* Pix */}
        <button
          onClick={() => setSelected("pix")}
          className="w-full bg-white rounded-2xl p-4 flex items-center gap-3 shadow-sm text-left transition hover:bg-slate-50"
        >
          <span
            className="h-11 w-11 rounded-xl flex items-center justify-center shrink-0"
            style={{ backgroundColor: "#E8FAF4" }}
          >
            <PixIcon />
          </span>
          <span className="flex-1">
            <span className="block font-bold" style={{ color: DARK }}>
              Pix
            </span>
            <span className="block text-sm text-slate-500">Pague com Pix à vista</span>
          </span>
          <Radio active={selected === "pix"} />
        </button>

        <h2 className="mt-7 mb-3 font-bold" style={{ color: DARK }}>
          Cartão de crédito
        </h2>

        <div className="space-y-3">
          {cardOptions.map((opt) => (
            <button
              key={opt.id}
              onClick={() => setSelected(opt.id)}
              className="w-full bg-white rounded-xl px-4 py-3.5 flex items-center justify-between shadow-sm text-left transition hover:bg-slate-50"
            >
              <span className="text-sm" style={{ color: DARK }}>
                {opt.label}
              </span>
              <span className="flex items-center gap-3">
                <span className="text-sm font-medium" style={{ color: DARK }}>
                  {opt.value}
                </span>
                <Radio active={selected === opt.id} />
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="p-5">
        <PrimaryButton onClick={handleNext}>Continuar</PrimaryButton>
      </div>
    </div>
  )
}

function Radio({ active }: { active: boolean }) {
  return (
    <span
      className="h-6 w-6 rounded-full flex items-center justify-center shrink-0 border-2"
      style={{
        backgroundColor: active ? GREEN : "transparent",
        borderColor: active ? GREEN : "#CBD5E1",
      }}
    >
      {active && <Check className="h-4 w-4 text-white" strokeWidth={3} />}
    </span>
  )
}

function PixIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path
        d="M12 2.5l3 3-3 3-3-3 3-3zM5.5 9l3 3-3 3-3-3 3-3zM18.5 9l3 3-3 3-3-3 3-3zM12 15.5l3 3-3 3-3-3 3-3z"
        fill="#00C896"
      />
    </svg>
  )
}

/* ---------------- View 2.5: Pix Screen ---------------- */
function PixView({ onBack, onSimulate }: { onBack: () => void; onSimulate: () => void }) {
  return (
    <div className="flex flex-col h-full">
      <header
        className="px-5 pt-6 pb-5 flex items-center gap-3 rounded-b-3xl"
        style={{ backgroundColor: GREEN }}
      >
        <button onClick={onBack} aria-label="Voltar" className="p-2 -ml-2 rounded-full hover:bg-black/10 transition-colors">
          <ArrowLeft className="h-6 w-6" style={{ color: DARK }} />
        </button>
        <h1 className="text-lg font-bold" style={{ color: DARK }}>
          Pagamento via Pix
        </h1>
      </header>

      <div className="flex-1 flex flex-col items-center px-6 pt-10">
        <p className="text-center text-slate-600 mb-6 font-medium">
          Escaneie o QR Code abaixo ou copie o código para realizar o pagamento.
        </p>
        
        <div className="bg-white p-5 rounded-3xl shadow-sm mb-8 flex items-center justify-center">
          <QrCode className="w-48 h-48 text-slate-800" strokeWidth={1} />
        </div>

        <button className="flex items-center gap-2 bg-white px-6 py-3.5 rounded-full shadow-sm font-bold text-slate-700 hover:bg-slate-50 transition-colors active:scale-95">
          <Copy className="w-5 h-5 text-slate-500" />
          Copiar código Pix
        </button>
      </div>

      <div className="p-5">
        <PrimaryButton onClick={onSimulate}>Efetuar pagamento</PrimaryButton>
      </div>
    </div>
  )
}

/* ---------------- View 2.6: Card Screen ---------------- */
function CardPaymentView({ onBack, onPay }: { onBack: () => void; onPay: () => void }) {
  return (
    <div className="flex flex-col h-full">
      <header
        className="px-5 pt-6 pb-5 flex items-center gap-3 rounded-b-3xl"
        style={{ backgroundColor: GREEN }}
      >
        <button onClick={onBack} aria-label="Voltar" className="p-2 -ml-2 rounded-full hover:bg-black/10 transition-colors">
          <ArrowLeft className="h-6 w-6" style={{ color: DARK }} />
        </button>
        <h1 className="text-lg font-bold" style={{ color: DARK }}>
          Dados do Cartão
        </h1>
      </header>

      <div className="flex-1 overflow-y-auto px-5 pt-6 space-y-5">
        <div className="bg-white p-4 rounded-2xl shadow-sm flex items-center gap-4 mb-2">
          <div className="h-12 w-12 rounded-xl bg-slate-100 flex items-center justify-center">
            <CreditCard className="w-6 h-6 text-slate-600" />
          </div>
          <div>
            <p className="font-bold text-sm" style={{ color: DARK }}>Total a pagar</p>
            <p className="font-bold text-lg" style={{ color: GREEN }}>R$ 1.200,00</p>
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-sm font-bold text-slate-700 ml-1">Número do Cartão</label>
          <input 
            type="text" 
            placeholder="0000 0000 0000 0000" 
            className="w-full bg-white rounded-xl p-3.5 shadow-sm outline-none border-2 border-transparent focus:border-[#00C896] transition-colors font-medium text-slate-700 placeholder:text-slate-400" 
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-sm font-bold text-slate-700 ml-1">Nome do Titular</label>
          <input 
            type="text" 
            placeholder="Nome impresso no cartão" 
            className="w-full bg-white rounded-xl p-3.5 shadow-sm outline-none border-2 border-transparent focus:border-[#00C896] transition-colors font-medium text-slate-700 placeholder:text-slate-400" 
          />
        </div>

        <div className="flex gap-4">
          <div className="space-y-1.5 flex-1">
            <label className="text-sm font-bold text-slate-700 ml-1">Validade</label>
            <input 
              type="text" 
              placeholder="MM/AA" 
              className="w-full bg-white rounded-xl p-3.5 shadow-sm outline-none border-2 border-transparent focus:border-[#00C896] transition-colors font-medium text-slate-700 placeholder:text-slate-400" 
            />
          </div>
          <div className="space-y-1.5 flex-1">
            <label className="text-sm font-bold text-slate-700 ml-1">CVV</label>
            <input 
              type="text" 
              placeholder="123" 
              className="w-full bg-white rounded-xl p-3.5 shadow-sm outline-none border-2 border-transparent focus:border-[#00C896] transition-colors font-medium text-slate-700 placeholder:text-slate-400" 
            />
          </div>
        </div>
      </div>

      <div className="p-5">
        <PrimaryButton onClick={onPay}>Efetuar pagamento</PrimaryButton>
      </div>
    </div>
  )
}

/* ---------------- View 3: Processing ---------------- */
function ProcessingView({ onDone }: { onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2500)
    return () => clearTimeout(t)
  }, [onDone])

  return (
    <div className="flex flex-col h-full items-center justify-center px-8 text-center">
      <h1 className="text-2xl font-bold mb-12" style={{ color: DARK }}>
        Processando pagamento
      </h1>

      <div className="relative mb-8">
        <Smartphone className="h-24 w-24" style={{ color: GREEN }} strokeWidth={1.5} />
        <span className="absolute inset-0 flex items-center justify-center">
          <span
            className="text-[10px] font-bold px-1.5 py-0.5 rounded border-2"
            style={{ borderColor: GREEN, color: GREEN }}
          >
            $
          </span>
        </span>
      </div>

      <div
        className="h-9 w-9 rounded-full border-[3px] border-slate-300 animate-spin mb-6"
        style={{ borderTopColor: GREEN }}
      />

      <p className="text-slate-600 leading-relaxed">
        Aguarde enquanto
        <br />
        processamos seu pagamento...
      </p>
    </div>
  )
}

/* ---------------- View 4: Success ---------------- */
function SuccessView({ onChat }: { onChat: () => void }) {
  const [orderId, setOrderId] = useState("")

  useEffect(() => {
    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    const randomLetters = Array.from({length: 3}, () => letters[Math.floor(Math.random() * letters.length)]).join('')
    const randomNumbers = Math.floor(10000000 + Math.random() * 90000000)
    setOrderId(`#${randomLetters}${randomNumbers}`)
  }, [])

  return (
    <div className="flex flex-col h-full px-8 pb-8">
      <div className="flex-1 flex flex-col items-center justify-center text-center">
        <span
          className="h-28 w-28 rounded-full flex items-center justify-center mb-8"
          style={{ backgroundColor: GREEN }}
        >
          <Check className="h-14 w-14 text-white" strokeWidth={3} />
        </span>

        <h1 className="text-2xl font-bold mb-3" style={{ color: DARK }}>
          Pagamento Aprovado!
        </h1>
        <p className="text-slate-600 font-medium mb-8 leading-relaxed">
          Seu pedido foi realizado com
          <br />
          sucesso.
        </p>

        <p className="text-sm text-slate-500">Nº do pedido</p>
        <p className="font-bold tracking-wide" style={{ color: DARK }}>
          {orderId || "#Aguarde..."}
        </p>
      </div>

      <PrimaryButton onClick={onChat}>Combinar entrega no chat</PrimaryButton>
    </div>
  )
}

/* ---------------- View 5: Chat ---------------- */
type Message = { from: "me" | "them"; text: string; time: string }

function ChatView({ onBack }: { onBack: () => void }) {
  const messages: Message[] = [
    { from: "me", text: "Olá! Esse notebook ainda está disponível?", time: "10:24" },
    { from: "them", text: "Olá! Sim, ainda está disponível.", time: "10:25" },
    { from: "me", text: "Tem nota fiscal?", time: "10:25" },
    { from: "them", text: "Tenho sim, tudo completo.", time: "10:26" },
    { from: "me", text: "Ótimo! Vamos fechar negócio.", time: "10:30" },
  ]

  return (
    <div className="flex flex-col h-full bg-[#CFEFEC]">
      {/* Header */}
      <header
        className="px-4 pt-6 pb-4 flex items-center gap-2 rounded-b-3xl shadow-sm z-10"
        style={{ backgroundColor: "#7FB3E8" }}
      >
        <button onClick={onBack} aria-label="Voltar" className="p-2 -ml-2 rounded-full hover:bg-black/10 transition-colors">
          <ArrowLeft className="h-6 w-6" style={{ color: DARK }} />
        </button>
        <img
          src="/seller-avatar.png" 
          alt="Irinel Silva"
          className="h-11 w-11 rounded-full object-cover border-2 border-white ml-1 shadow-sm"
        />
        <div className="flex-1 ml-2">
          <p className="font-bold leading-tight" style={{ color: DARK }}>
            Irinel Silva
          </p>
          <p className="text-xs font-medium" style={{ color: DARK }}>
            online
          </p>
        </div>
        <button aria-label="Ligar" className="p-2 rounded-full hover:bg-black/10 transition-colors">
          <Phone className="h-5 w-5" style={{ color: DARK }} fill={DARK} />
        </button>
        <button aria-label="Mais opções" className="p-2 -mr-2 rounded-full hover:bg-black/10 transition-colors">
          <MoreVertical className="h-5 w-5" style={{ color: DARK }} />
        </button>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-3">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.from === "me" ? "justify-end" : "justify-start"}`}>
            <div
              className="max-w-[75%] rounded-2xl px-4 py-2.5 shadow-sm"
              style={{
                backgroundColor: m.from === "me" ? "#A4E869" : "#E2DEDE",
                color: DARK,
              }}
            >
              <p className="text-sm leading-snug">{m.text}</p>
              <p className="text-[10px] text-slate-600 text-right mt-1 font-medium">{m.time}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Input de Chat Perfeitamente Alinhado */}
      <div className="px-4 pb-6 pt-2">
        <div className="bg-white rounded-full flex items-center pl-2 pr-1.5 py-1.5 shadow-sm">
          <button className="p-2 rounded-full hover:bg-slate-100 transition-colors text-slate-400 shrink-0">
            <Paperclip className="h-5 w-5" />
          </button>
          <input
            type="text"
            placeholder="Digite sua mensagem..."
            className="flex-1 w-full bg-transparent outline-none px-2 text-sm text-slate-700 placeholder:text-slate-400"
          />
          <button className="p-2 rounded-full hover:bg-slate-100 transition-colors text-slate-400 shrink-0">
            <Mic className="h-5 w-5" />
          </button>
          <button
            className="h-9 w-9 ml-1 rounded-full flex items-center justify-center shrink-0 transition-transform active:scale-95 shadow-sm"
            style={{ backgroundColor: GREEN }}
            aria-label="Enviar"
          >
            <Send className="h-4 w-4 text-white -ml-0.5" />
          </button>
        </div>
      </div>
    </div>
  )
}

/* ---------------- Shared ---------------- */
function PrimaryButton({
  children,
  onClick,
}: {
  children: React.ReactNode
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className="w-full rounded-full py-4 font-bold text-white shadow-md hover:brightness-105 active:scale-[0.98] transition-all"
      style={{ backgroundColor: GREEN }}
    >
      {children}
    </button>
  )
}