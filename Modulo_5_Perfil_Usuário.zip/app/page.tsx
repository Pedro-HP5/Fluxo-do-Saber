"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, Pencil, Package, LogOut, Trash2, User } from "lucide-react"

type Ad = {
  id: number
  title: string
  price: string
  color: string
}

const INITIAL_ADS: Ad[] = [
  { id: 1, title: "Cálculo Volume 1 - Guidorizzi", price: "R$ 45,00", color: "#FDE68A" },
  { id: 2, title: "Notebook Dell Inspiron 15", price: "R$ 1.890,00", color: "#BFDBFE" },
  { id: 3, title: "Kit Anatomia - Atlas Netter", price: "R$ 120,00", color: "#FBCFE8" },
  { id: 4, title: "Calculadora HP 12C", price: "R$ 230,00", color: "#C7F9CC" },
]

export default function Page() {
  const [view, setView] = useState<"profile" | "my-ads">("profile")
  const [modal, setModal] = useState<null | "delete-confirm">(null)
  const [ads, setAds] = useState<Ad[]>(INITIAL_ADS)
  const [pendingDelete, setPendingDelete] = useState<number | null>(null)

  function openDelete(id: number) {
    setPendingDelete(id)
    setModal("delete-confirm")
  }

  function confirmDelete() {
    if (pendingDelete !== null) {
      setAds((prev) => prev.filter((ad) => ad.id !== pendingDelete))
    }
    setModal(null)
    setPendingDelete(null)
  }

  return (
    <div className="min-h-screen w-full bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-[375px] h-[812px] max-h-[812px] mx-auto bg-[#CFEFEC] shadow-2xl relative overflow-hidden rounded-[2.5rem] border-[6px] border-gray-900 flex flex-col">
        {/* Header */}
        <header className="bg-[#00C896] pt-8 pb-5 px-5 flex items-center gap-3 shrink-0">
          {/* Botão de Voltar universal */}
          <button
            type="button"
            onClick={() => view === "my-ads" ? setView("profile") : alert("Voltando para a Home do App...")}
            aria-label="Voltar"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/20 text-white transition-colors active:bg-white/30"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold text-white">{view === "profile" ? "Perfil" : "Meus Anúncios"}</h1>
        </header>

        {/* Body */}
        <main className="flex-1 overflow-y-auto px-5 py-6">
          {view === "profile" ? (
            <ProfileView onMyAds={() => setView("my-ads")} />
          ) : (
            <MyAdsView ads={ads} onDelete={openDelete} />
          )}
        </main>

        {/* Modal */}
        {modal === "delete-confirm" && (
          <div className="absolute inset-0 z-20 flex items-center justify-center bg-gray-900/40 px-6">
            <div className="w-full max-w-[300px] rounded-[2rem] bg-white p-8 text-center shadow-2xl">
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-red-100">
                <Trash2 className="h-7 w-7 text-[#EF4444]" />
              </div>
              <h2 className="text-lg font-bold text-[#0F172A]">Excluir anúncio?</h2>
              <p className="mt-2 text-sm leading-relaxed text-gray-500">
                Tem certeza que deseja remover este anúncio permanentemente?
              </p>
              <div className="mt-6 flex flex-col gap-3">
                <button
                  type="button"
                  onClick={confirmDelete}
                  className="w-full rounded-2xl bg-[#EF4444] py-3.5 text-sm font-semibold text-white transition-transform active:scale-[0.98]"
                >
                  Excluir
                </button>
                <button
                  type="button"
                  onClick={() => setModal(null)}
                  className="w-full rounded-2xl bg-gray-100 py-3.5 text-sm font-semibold text-[#0F172A] transition-transform active:scale-[0.98]"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function ProfileView({ onMyAds }: { onMyAds: () => void }) {
  return (
    <div className="flex flex-col">
      {/* Avatar + info */}
      <div className="flex flex-col items-center pb-8 pt-2">
        <div className="flex h-24 w-24 items-center justify-center rounded-full bg-white shadow-lg ring-4 ring-white">
          <User className="h-12 w-12 text-[#00C896]" />
        </div>
        <h2 className="mt-4 text-xl font-bold text-[#0F172A]">Seu Nome</h2>
        <p className="mt-1 text-sm text-gray-500">email@estudante.com</p>
      </div>

      {/* Menu */}
      <div className="flex flex-col gap-3">
        <MenuItem 
            icon={<Pencil className="h-5 w-5 text-[#00C896]" />} 
            label="Editar Perfil" 
            onClick={() => alert("Tela de edição em breve!")} 
        />
        <MenuItem icon={<Package className="h-5 w-5 text-[#00C896]" />} label="Meus Anúncios" onClick={onMyAds} />
        <MenuItem
          icon={<LogOut className="h-5 w-5 text-red-500" />}
          label="Sair"
          labelClassName="text-red-500"
          hideChevron
          onClick={() => alert("Saindo da conta...")}
        />
      </div>
    </div>
  )
}

function MenuItem({
  icon,
  label,
  onClick,
  labelClassName = "text-[#0F172A]",
  hideChevron = false,
}: {
  icon: React.ReactNode
  label: string
  onClick?: () => void
  labelClassName?: string
  hideChevron?: boolean
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-4 rounded-2xl bg-white px-4 py-4 shadow-sm transition-transform active:scale-[0.98]"
    >
      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#CFEFEC]">{icon}</span>
      <span className={`flex-1 text-left text-[15px] font-semibold ${labelClassName}`}>{label}</span>
      {!hideChevron && <ChevronRight className="h-5 w-5 text-gray-300" />}
    </button>
  )
}

function MyAdsView({ ads, onDelete }: { ads: Ad[]; onDelete: (id: number) => void }) {
  if (ads.length === 0) {
    return (
      <div className="flex h-full flex-col items-center justify-center pt-20 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-white shadow-sm">
          <Package className="h-8 w-8 text-[#00C896]" />
        </div>
        <p className="mt-4 text-sm font-medium text-gray-500">Você não tem anúncios ativos.</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-3">
      {ads.map((ad) => (
        <div key={ad.id} className="flex items-center gap-3 rounded-2xl bg-white p-3 shadow-sm">
          <div
            className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl"
            style={{ backgroundColor: ad.color }}
          >
            <Package className="h-7 w-7 text-gray-900/40" />
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="truncate text-[15px] font-semibold text-[#0F172A]">{ad.title}</h3>
            <p className="mt-1 text-sm font-bold text-[#00C896]">{ad.price}</p>
          </div>
          <button
            type="button"
            onClick={() => onDelete(ad.id)}
            aria-label={`Excluir ${ad.title}`}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-50 text-[#EF4444] transition-transform active:scale-90"
          >
            <Trash2 className="h-5 w-5" />
          </button>
        </div>
      ))}
    </div>
  )
}