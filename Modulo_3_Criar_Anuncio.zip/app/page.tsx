"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Camera, Check, ChevronDown } from "lucide-react"

const PRIMARY = "#00C896"
const TEXT = "#0F172A"

export default function Home() {
  const [view, setView] = useState<"menu" | "create" | "trade">("menu")
  const [modal, setModal] = useState<"success-create" | "success-trade" | null>(null)

  useEffect(() => {
    if (!modal) return
    const t = setTimeout(() => {
      setModal(null)
      setView("menu")
    }, 2000)
    return () => clearTimeout(t)
  }, [modal])

  return (
    <main className="flex min-h-screen w-full items-center justify-center bg-gray-900 p-4">
      <div className="w-full max-w-[375px] h-[812px] max-h-[812px] mx-auto bg-[#CFEFEC] shadow-2xl relative overflow-hidden rounded-[2.5rem] border-[6px] border-gray-900 flex flex-col">
        {view === "menu" && <MenuView onCreate={() => setView("create")} onTrade={() => setView("trade")} />}
        {view === "create" && <CreateView onBack={() => setView("menu")} onPublish={() => setModal("success-create")} />}
        {view === "trade" && <TradeView onBack={() => setView("menu")} onSend={() => setModal("success-trade")} />}

        {modal && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="flex w-[240px] flex-col items-center gap-5 rounded-[2rem] bg-white px-8 py-10 shadow-2xl animate-in zoom-in-95 duration-200">
              <p className="text-[22px] text-center font-bold leading-tight" style={{ color: TEXT }}>
                {modal === "success-create" ? "Anúncio Publicado" : "Proposta enviada"}
              </p>
              <div
                className="flex h-20 w-20 items-center justify-center rounded-full shadow-md"
                style={{ backgroundColor: PRIMARY }}
              >
                <Check className="h-10 w-10 text-white" strokeWidth={3.5} />
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  )
}

function MenuView({ onCreate, onTrade }: { onCreate: () => void; onTrade: () => void }) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-6 px-8">
      <h1 className="text-2xl font-bold" style={{ color: TEXT }}>
        Módulo 5
      </h1>
      <p className="mb-4 text-center text-sm text-slate-600 font-medium">Menu provisório para testar fluxos</p>
      <button
        onClick={onCreate}
        className="w-full rounded-full py-4 text-base font-bold text-white shadow-md transition-all hover:brightness-105 active:scale-95"
        style={{ backgroundColor: PRIMARY }}
      >
        Testar Novo Anúncio
      </button>
      <button
        onClick={onTrade}
        className="w-full rounded-full py-4 text-base font-bold text-white shadow-md transition-all hover:brightness-105 active:scale-95"
        style={{ backgroundColor: PRIMARY }}
      >
        Testar Propor Troca
      </button>
    </div>
  )
}

function Header({ title, onBack }: { title: string; onBack: () => void }) {
  return (
    <header className="flex items-center gap-3 px-4 py-5 rounded-b-3xl shadow-sm z-10" style={{ backgroundColor: PRIMARY }}>
      <button onClick={onBack} className="rounded-full p-2 transition-colors hover:bg-black/10 -ml-1" aria-label="Voltar">
        <ArrowLeft className="h-6 w-6" style={{ color: TEXT }} />
      </button>
      <h2 className="flex-1 text-center text-lg font-bold" style={{ color: TEXT }}>
        {title}
      </h2>
      <span className="w-10" aria-hidden="true" />
    </header>
  )
}

function CreateView({ onBack, onPublish }: { onBack: () => void; onPublish: () => void }) {
  return (
    <div className="flex flex-1 flex-col overflow-y-auto">
      <Header title="Novo Anúncio" onBack={onBack} />

      <div className="flex flex-1 flex-col gap-6 px-6 py-8">
        {/* Photos */}
        <div className="flex gap-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="flex aspect-square flex-1 items-center justify-center rounded-[1.5rem] bg-white/60 shadow-sm cursor-pointer hover:bg-white/80 transition-colors border-2 border-dashed border-slate-300">
              <Camera className="h-7 w-7 text-slate-400" />
            </div>
          ))}
        </div>

        {/* Form */}
        <div className="flex flex-col gap-5 mt-2">
          <div className="flex flex-col gap-1.5">
            <label className="text-base font-bold ml-1" style={{ color: TEXT }}>
              Título do anúncio
            </label>
            <input
              type="text"
              placeholder="Ex.: Livro de Física"
              className="w-full rounded-xl border-2 border-transparent bg-white shadow-sm px-4 py-3.5 text-sm text-slate-800 font-medium outline-none focus:border-[#00C896] placeholder:text-slate-400 transition-colors"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-base font-bold ml-1" style={{ color: TEXT }}>
              Categoria
            </label>
            <div className="relative">
              <select
                defaultValue=""
                className="w-full appearance-none rounded-xl border-2 border-transparent bg-white shadow-sm px-4 py-3.5 text-sm text-slate-800 font-medium outline-none focus:border-[#00C896] transition-colors cursor-pointer"
              >
                <option value="" disabled>Selecione uma categoria</option>
                <option value="livros">Livros e materiais</option>
                <option value="eletronicos">Eletrônicos</option>
                <option value="acessorios">Acessórios</option>
                <option value="equipamentos">Equipamentos técnicos</option>
                <option value="pessoais">Itens pessoais</option>
                <option value="lazer">Lazer</option>
              </select>
              <ChevronDown className="pointer-events-none absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-base font-bold ml-1" style={{ color: TEXT }}>
              Tipo do anúncio
            </label>
            <CheckboxGroup />
          </div>
        </div>

        <div className="mt-auto pt-6 pb-4">
          <button
            onClick={onPublish}
            className="w-full rounded-full py-4 text-base font-bold text-white shadow-md transition-all hover:brightness-105 active:scale-95"
            style={{ backgroundColor: PRIMARY }}
          >
            Publicar
          </button>
        </div>
      </div>
    </div>
  )
}

function CheckboxGroup() {
  const [venda, setVenda] = useState(false)
  const [troca, setTroca] = useState(false)

  return (
    <div className="flex gap-3">
      <button
        onClick={() => setVenda(!venda)}
        className={`flex flex-1 items-center gap-3 rounded-xl border-2 bg-white px-4 py-3.5 shadow-sm transition-colors active:scale-95 ${
          venda ? "border-[#00C896]" : "border-transparent"
        }`}
      >
        <span
          className={`flex h-5 w-5 items-center justify-center rounded border-2 transition-colors ${
            venda ? "bg-[#00C896] border-[#00C896]" : "border-slate-300"
          }`}
        >
          {venda && <Check className="h-3.5 w-3.5 text-white" strokeWidth={3} />}
        </span>
        <span className="text-sm font-bold" style={{ color: TEXT }}>
          Venda
        </span>
      </button>

      <button
        onClick={() => setTroca(!troca)}
        className={`flex flex-1 items-center gap-3 rounded-xl border-2 bg-white px-4 py-3.5 shadow-sm transition-colors active:scale-95 ${
          troca ? "border-[#00C896]" : "border-transparent"
        }`}
      >
        <span
          className={`flex h-5 w-5 items-center justify-center rounded border-2 transition-colors ${
            troca ? "bg-[#00C896] border-[#00C896]" : "border-slate-300"
          }`}
        >
          {troca && <Check className="h-3.5 w-3.5 text-white" strokeWidth={3} />}
        </span>
        <span className="text-sm font-bold" style={{ color: TEXT }}>
          Troca
        </span>
      </button>
    </div>
  )
}

function TradeView({ onBack, onSend }: { onBack: () => void; onSend: () => void }) {
  return (
    <div className="flex flex-1 flex-col overflow-y-auto">
      <Header title="propor trocar" onBack={onBack} />

      <div className="flex flex-1 flex-col gap-4 px-6 py-8">
        <div className="flex flex-col gap-1">
          <div className="flex justify-end">
            <button className="text-sm font-bold hover:underline transition-all active:scale-95" style={{ color: PRIMARY }}>
              Editar
            </button>
          </div>
          {/* Preço removido do item do usuário ofertante */}
          <ItemRow title="Livro de Física" kind="book" />
        </div>

        <div className="h-px w-full bg-slate-300 my-1" />

        <div className="flex flex-col gap-1">
          <div className="flex justify-end">
            <button className="text-sm font-bold hover:underline transition-all active:scale-95" style={{ color: PRIMARY }}>
              Ver anúncio
            </button>
          </div>
          {/* Preço mantido no item alvo da troca */}
          <ItemRow title="Notebook Dell" price="R$ 1.200,00" kind="laptop" />
        </div>

        <div className="mt-6 flex flex-col gap-1.5">
          <label className="text-sm font-bold ml-1" style={{ color: TEXT }}>
            Mensagem (opcional)
          </label>
          <textarea
            rows={4}
            placeholder="Tenho interesse em trocar. Podemos conversar?"
            className="w-full resize-none rounded-xl border-2 border-transparent bg-white shadow-sm px-4 py-3.5 text-sm text-slate-800 font-medium outline-none focus:border-[#00C896] placeholder:text-slate-400 transition-colors"
          />
        </div>

        <div className="mt-auto pt-4 pb-4">
          <button
            onClick={onSend}
            className="w-full rounded-full py-4 text-base font-bold text-white shadow-md transition-all hover:brightness-105 active:scale-95"
            style={{ backgroundColor: PRIMARY }}
          >
            Enviar proposta
          </button>
        </div>
      </div>
    </div>
  )
}

function ItemRow({ title, price, kind }: { title: string; price?: string; kind: "book" | "laptop" }) {
  return (
    <div className="flex items-center gap-4 bg-white/40 p-2 rounded-2xl">
      <div className="flex h-16 w-16 items-center justify-center overflow-hidden rounded-[1rem] bg-white shadow-sm">
        <ItemIcon kind={kind} />
      </div>
      <div className="flex flex-col">
        <span className="text-base font-bold" style={{ color: TEXT }}>
          {title}
        </span>
        {price && (
          <span className="text-sm font-medium mt-0.5" style={{ color: TEXT }}>
            {price}
          </span>
        )}
      </div>
    </div>
  )
}

function ItemIcon({ kind }: { kind: "book" | "laptop" }) {
  if (kind === "book") {
    return (
      <div className="flex h-12 w-9 flex-col items-center justify-start rounded-sm bg-blue-900 px-1 py-1 text-[6px] font-bold text-white shadow-sm">
        <span>FÍSICA</span>
        <span className="mt-2 h-4 w-6 rounded-sm bg-white/20" />
      </div>
    )
  }
  return (
    <div className="flex flex-col items-center shadow-sm">
      <div className="h-8 w-11 rounded-sm border-2 border-gray-700 bg-gradient-to-br from-sky-400 to-blue-700" />
      <div className="h-1 w-12 rounded-b-sm bg-gray-700" />
    </div>
  )
}